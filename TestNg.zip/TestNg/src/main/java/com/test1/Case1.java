package com.test1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Case1 {

	public String url = "https://www.flipkart.com/";
	String driverPath = "C:\\Software\\Selenium Files\\chromedriver.exe";
	public WebDriver driver;
	public WebDriverWait wait;
	Properties prop;

	@BeforeTest
	public void launchBrowser() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", driverPath);
		driver = new ChromeDriver();
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test
	public void Login() throws IOException, InterruptedException {
		Properties prop=new Properties();
		FileInputStream ip= new FileInputStream("config.properties");
		prop.load(ip);
		String us=prop.getProperty("userName");
		String ps=prop.getProperty("Password");
		
		driver.findElement(By.xpath("//div[@class='IiD88i _351hSN'][1]/input")).sendKeys(us);
		driver.findElement(By.xpath("//div[@class='IiD88i _351hSN'][2]/input")).sendKeys(ps);
		driver.findElement(By.cssSelector("button[class='_2KpZ6l _2HKlqd _3AWRsL']")).click();
		// Thread.sleep(3000);
		
		driver.findElement(By.cssSelector("input[title='Search for products, brands and more']"))
				.sendKeys("Apple iPhone XR");
		Thread.sleep(100);
		driver.findElement(By.cssSelector("button[type='submit']")).click();
	}

	@Test
	public void selectProduct() {
		wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(By.xpath("//a[contains(@href,'apple-iphone-xr-white-64-gb')]/div[2]")));

		// Thread.sleep(3000);
		// driver.findElement(By.cssSelector("a[title='Apple iPhone XR (White, 64 GB)
		// (Includes EarPods, Power Adapter)']")).click();
		// driver.findElement(By.xpath("//div[@class='_13oc-S']/div/div/a")).click();
		driver.findElement(By.xpath("//a[contains(@href,'apple-iphone-xr-white-64-gb')]/div[2]")).click();
	}

	@Test
	public void addToCart() {
		String mainWindow = driver.getWindowHandle();
		Set<String> allWindows = driver.getWindowHandles();
		Iterator<String> iterator = allWindows.iterator();

		while (iterator.hasNext()) {
			String ChildWindow = iterator.next();
			driver.switchTo().window(ChildWindow);
			System.out.println(driver.switchTo().window(ChildWindow).getTitle());
			// Thread.sleep(3000);

			driver.findElement(By.linkText("ADD TO CART")).click();
			// Thread.sleep(3000);
			boolean list = driver.findElements(By.xpath("a[contains(@href,'apple-iphone-xr-white-64')]")).size() != 0;
			if (list == true) {
				System.out.println("The element is present ");
			} else {
				System.out.println("The element doesnot exists");
			}

		}
		// validation in cart
	}

	@AfterTest
	public void Logout() {
		driver.findElement(By.linkText("Nancy")).click();
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.linkText("logout")));

		driver.findElement(By.linkText("logout")).click();
	}

}
